package dev.mending.cosmetics.api.model;

import java.time.Duration;

/**
 * Short result of a registry reload.
 *
 * @param files    number of YAML files scanned
 * @param loaded   number of cosmetics now in the registry from files
 * @param skipped  number of cosmetic definitions rejected because of errors
 * @param warnings number of warnings
 * @param duration wall-clock duration of the load
 */
public record ReloadSummary(int files, int loaded, int skipped, int warnings, Duration duration) {
}