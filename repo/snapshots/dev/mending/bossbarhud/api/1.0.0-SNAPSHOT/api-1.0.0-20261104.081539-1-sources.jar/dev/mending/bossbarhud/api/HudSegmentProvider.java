package dev.mending.bossbarhud.api;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Supplies the content of one HUD box for a player.
 * Called on the main thread on every HUD update.
 */
@FunctionalInterface
public interface HudSegmentProvider {

    /**
     * @param player the viewer
     * @return the content of the box, or null to hide the box for this player
     */
    @Nullable Component render(@NotNull Player player);

    /**
     * Creates a provider that always returns the same content.
     */
    static @NotNull HudSegmentProvider constant(@NotNull Component content) {
        return player -> content;
    }
}