package dev.mending.bossbarhud.api;

import net.kyori.adventure.text.Component;
import org.jetbrains.annotations.NotNull;

/**
 * Builder for a {@link Hud}. Obtain it via {@link HudAPI#createHud}.
 */
public interface HudBuilder {

    /** Lower priority = further left. Default is 0. */
    @NotNull HudBuilder priority(int priority);

    /** Makes the HUD visible to everyone. Without this the HUD is personal. */
    @NotNull HudBuilder global();

    @NotNull HudBuilder segment(@NotNull String id, int order, @NotNull HudSegmentProvider provider);

    @NotNull HudBuilder segment(@NotNull String id, int order, @NotNull Component content);

    /**
     * Registers the HUD.
     *
     * @throws IllegalStateException if the plugin already registered a HUD with this id
     */
    @NotNull Hud build();
}