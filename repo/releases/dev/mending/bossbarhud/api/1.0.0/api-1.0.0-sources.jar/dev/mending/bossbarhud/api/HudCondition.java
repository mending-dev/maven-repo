package dev.mending.bossbarhud.api;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

/**
 * Decides whether a box is shown to a player. A box without a condition is always shown.
 * <p>
 * Conditions are evaluated on the main thread before the content of the box is rendered, on every HUD update,
 * so keep them fast. A box whose condition is false is not rendered at all (its provider is not called).
 * <p>
 * Use a lambda for checks in code, or {@link HudAPI#condition(String)} for the same expressions that admins
 * write in {@code config.yml}:
 *
 * <pre>{@code
 * HudCondition inNether = player -> player.getWorld().getEnvironment() == World.Environment.NETHER;
 * HudCondition vip = HudAPI.get().condition("permission=server.vip && %player_level% >= 10");
 *
 * hud.setSegment("bonus", 1, 0, provider, inNether.and(vip));
 * }</pre>
 *
 * @since 1.0.0
 */
@FunctionalInterface
public interface HudCondition {

    /**
     * @param player the viewer
     * @return true to show the box to this player
     */
    boolean test(@NotNull Player player);

    /** A condition that is always true (the same as no condition). */
    static @NotNull HudCondition always() {
        return player -> true;
    }

    /** True if this and the other condition are true. The other one is only evaluated if this one is true. */
    default @NotNull HudCondition and(@NotNull HudCondition other) {
        Objects.requireNonNull(other, "other");
        return player -> test(player) && other.test(player);
    }

    /** True if this or the other condition is true. The other one is only evaluated if this one is false. */
    default @NotNull HudCondition or(@NotNull HudCondition other) {
        Objects.requireNonNull(other, "other");
        return player -> test(player) || other.test(player);
    }

    /** The opposite of this condition. */
    default @NotNull HudCondition negate() {
        return player -> !test(player);
    }
}
