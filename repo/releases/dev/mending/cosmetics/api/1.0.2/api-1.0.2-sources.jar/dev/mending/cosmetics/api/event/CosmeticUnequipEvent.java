package dev.mending.cosmetics.api.event;

import dev.mending.cosmetics.api.Cosmetic;
import dev.mending.cosmetics.api.CosmeticUser;
import dev.mending.cosmetics.api.model.EquipCause;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired on the main thread before a cosmetic is removed. Cancelling is ignored when
 * {@link EquipCause#isForced()} is true (e.g. permission loss).
 */
public final class CosmeticUnequipEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final CosmeticUser user;
    private final Cosmetic cosmetic;
    private final EquipCause cause;
    private boolean cancelled;

    public CosmeticUnequipEvent(CosmeticUser user, Cosmetic cosmetic, EquipCause cause) {
        this.user = user;
        this.cosmetic = cosmetic;
        this.cause = cause;
    }

    public CosmeticUser user() {
        return user;
    }

    public Cosmetic cosmetic() {
        return cosmetic;
    }

    public EquipCause cause() {
        return cause;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}