package dev.mending.bossbarhud.api;

import net.kyori.adventure.text.Component;
import org.jetbrains.annotations.NotNull;

/**
 * Builder for a {@link Hud}. Obtain it via {@link HudAPI#createHud}.
 */
public interface HudBuilder {

    /** Lower priority = further left inside a line. Default is 0. */
    @NotNull HudBuilder priority(int priority);

    /** Makes the HUD visible to everyone. Without this the HUD is personal. */
    @NotNull HudBuilder global();

    /** Adds a box on {@link Hud#DEFAULT_LINE}. */
    @NotNull HudBuilder segment(@NotNull String id, int order, @NotNull HudSegmentProvider provider);

    /**
     * Adds a box on the given line.
     *
     * @param id       id of the box, unique inside the HUD
     * @param line     the line (row) of the box, boxes with the same line are placed next to each other
     * @param order    position inside the line, from left to right
     * @param provider supplies the content for each viewer
     */
    @NotNull HudBuilder segment(@NotNull String id, int line, int order, @NotNull HudSegmentProvider provider);

    /** Adds a box with static content on {@link Hud#DEFAULT_LINE}. */
    @NotNull HudBuilder segment(@NotNull String id, int order, @NotNull Component content);

    /** Adds a box with static content on the given line. */
    @NotNull HudBuilder segment(@NotNull String id, int line, int order, @NotNull Component content);

    /**
     * Adds a box on the given line that is only shown to players for whom the condition is true.
     *
     * @param condition checked before the provider is called; false hides the box for that player
     * @see HudCondition
     * @since 1.0.0
     */
    @NotNull HudBuilder segment(@NotNull String id, int line, int order, @NotNull HudSegmentProvider provider,
                                @NotNull HudCondition condition);

    /**
     * Adds a box with static content on the given line that is only shown to players for whom the condition is true.
     *
     * @since 1.0.0
     */
    @NotNull HudBuilder segment(@NotNull String id, int line, int order, @NotNull Component content,
                                @NotNull HudCondition condition);

    /**
     * Registers the HUD.
     *
     * @throws IllegalStateException if the plugin already registered a HUD with this id
     */
    @NotNull Hud build();
}