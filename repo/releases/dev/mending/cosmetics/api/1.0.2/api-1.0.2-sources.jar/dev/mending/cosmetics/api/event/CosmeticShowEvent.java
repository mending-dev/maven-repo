package dev.mending.cosmetics.api.event;

import dev.mending.cosmetics.api.CosmeticSlot;
import dev.mending.cosmetics.api.CosmeticUser;
import net.kyori.adventure.key.Key;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.Nullable;

/** Fired on the main thread before a hide reason is removed. Cancelling keeps the reason. */
public final class CosmeticShowEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final CosmeticUser user;
    private final Key reason;
    private final @Nullable CosmeticSlot slot;
    private boolean cancelled;

    public CosmeticShowEvent(CosmeticUser user, Key reason, @Nullable CosmeticSlot slot) {
        this.user = user;
        this.reason = reason;
        this.slot = slot;
    }

    public CosmeticUser user() {
        return user;
    }

    public Key reason() {
        return reason;
    }

    /** Returns the slot, or {@code null} if the reason applied to all slots. */
    public @Nullable CosmeticSlot slot() {
        return slot;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
