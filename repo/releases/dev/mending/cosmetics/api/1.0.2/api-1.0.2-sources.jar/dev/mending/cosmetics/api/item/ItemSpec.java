package dev.mending.cosmetics.api.item;

import net.kyori.adventure.key.Key;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;

/**
 * Declarative description of an item, resolved lazily by an {@link ItemProvider}.
 * Optional fields that are {@code null} (or an empty lore) are NOT applied, so data components of
 * custom items (e.g. Nexo) are never overwritten unless explicitly configured.
 *
 * @param namespace   provider namespace, e.g. {@code minecraft} or {@code nexo}
 * @param id          provider specific id
 * @param amount      stack size 1..99
 * @param name        optional MiniMessage display name override
 * @param lore        optional MiniMessage lore override (empty = unset)
 * @param glint       optional enchantment glint override
 * @param itemModel   optional item-model override
 * @param hideTooltip optional hide-tooltip override
 */
public record ItemSpec(
        String namespace,
        String id,
        int amount,
        @Nullable String name,
        List<String> lore,
        @Nullable Boolean glint,
        @Nullable Key itemModel,
        @Nullable Boolean hideTooltip
) {
    /** Namespace used for bare material names. */
    public static final String DEFAULT_NAMESPACE = "minecraft";

    public ItemSpec {
        Objects.requireNonNull(namespace, "namespace");
        Objects.requireNonNull(id, "id");
        if (namespace.isBlank() || id.isBlank()) {
            throw new IllegalArgumentException("namespace and id must not be blank");
        }
        if (amount < 1 || amount > 99) {
            throw new IllegalArgumentException("amount must be between 1 and 99, was " + amount);
        }
        lore = List.copyOf(lore);
    }

    /**
     * Parses a short source such as {@code nexo:crow_hat}, {@code minecraft:stick} or {@code stick}.
     *
     * @param source the raw source string
     * @return a spec with no overrides and amount 1
     * @throws IllegalArgumentException if the source is malformed
     */
    public static ItemSpec of(String source) {
        String s = source.trim();
        if (s.isEmpty()) {
            throw new IllegalArgumentException("item source is empty");
        }
        int colon = s.indexOf(':');
        String namespace;
        String id;
        if (colon < 0) {
            namespace = DEFAULT_NAMESPACE;
            id = s;
        } else {
            namespace = s.substring(0, colon).toLowerCase(java.util.Locale.ROOT);
            id = s.substring(colon + 1);
        }
        if (namespace.isEmpty() || !namespace.chars().allMatch(c -> (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                || c == '_' || c == '-' || c == '.')) {
            throw new IllegalArgumentException("invalid item namespace in '" + source + "'");
        }
        if (id.isEmpty() || id.chars().anyMatch(Character::isWhitespace)) {
            throw new IllegalArgumentException("invalid item id in '" + source + "'");
        }
        if (DEFAULT_NAMESPACE.equals(namespace)) {
            id = id.toLowerCase(java.util.Locale.ROOT);
        }
        return new ItemSpec(namespace, id, 1, null, List.of(), null, null, null);
    }

    /** Returns {@code namespace:id}. */
    public String source() {
        return namespace + ':' + id;
    }
}