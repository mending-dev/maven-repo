package dev.mending.cosmetics.api;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;

/**
 * The fixed set of cosmetic slots. A player can wear one cosmetic per slot.
 */
public enum CosmeticSlot {
    HELMET,
    CHESTPLATE,
    LEGGINGS,
    BOOTS,
    OFFHAND,
    /** Body-attached cosmetic (backpack, cloak, wings, halo, tail, ...). */
    ACCESSORY;

    private static final CosmeticSlot[] VALUES = values();

    /**
     * Parses a slot name case-insensitively.
     *
     * @param input the raw name, may be {@code null}
     * @return the slot, or empty if the name is unknown
     */
    public static Optional<CosmeticSlot> parse(@Nullable String input) {
        if (input == null) {
            return Optional.empty();
        }
        String trimmed = input.trim();
        for (CosmeticSlot slot : VALUES) {
            if (slot.name().equalsIgnoreCase(trimmed)) {
                return Optional.of(slot);
            }
        }
        return Optional.empty();
    }

    /** Returns {@code true} for slots rendered as equipment (everything except {@link #ACCESSORY}). */
    public boolean isEquipment() {
        return this != ACCESSORY;
    }
}