package dev.mending.cosmetics.api.model;

/** Player states in which an accessory can be hidden. */
public enum AccessoryState {
    SLEEPING,
    SWIMMING,
    GLIDING,
    RIPTIDE,
    /** Holding an item with the Riptide enchantment. Not part of the default list. */
    HOLDING_RIPTIDE
}