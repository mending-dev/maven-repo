package dev.mending.cosmetics.api.event;

import dev.mending.cosmetics.api.Cosmetic;
import dev.mending.cosmetics.api.CosmeticUser;
import dev.mending.cosmetics.api.model.EquipOptions;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import java.util.Objects;

/**
 * Fired on the main thread before a cosmetic is equipped. Cancel it to block the change, or call
 * {@link #setCosmetic(Cosmetic)} to equip a different (registered) cosmetic instead; the replacement is validated
 * again (permission, item availability) unless the equip bypasses permissions.
 */
public final class CosmeticEquipEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final CosmeticUser user;
    private final EquipOptions options;
    private Cosmetic cosmetic;
    private boolean cancelled;

    public CosmeticEquipEvent(CosmeticUser user, Cosmetic cosmetic, EquipOptions options) {
        this.user = user;
        this.cosmetic = cosmetic;
        this.options = options;
    }

    public CosmeticUser user() {
        return user;
    }

    public Cosmetic cosmetic() {
        return cosmetic;
    }

    /** Replaces the cosmetic that will be equipped. */
    public void setCosmetic(Cosmetic cosmetic) {
        this.cosmetic = Objects.requireNonNull(cosmetic, "cosmetic");
    }

    public EquipOptions options() {
        return options;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}