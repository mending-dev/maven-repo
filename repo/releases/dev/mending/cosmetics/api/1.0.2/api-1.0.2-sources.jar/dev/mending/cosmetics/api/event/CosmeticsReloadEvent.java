package dev.mending.cosmetics.api.event;

import dev.mending.cosmetics.api.model.ReloadSummary;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired on the main thread after the cosmetic registry snapshot has been swapped.
 */
public final class CosmeticsReloadEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final ReloadSummary summary;

    /**
     * Creates the event.
     *
     * @param summary the reload result
     */
    public CosmeticsReloadEvent(ReloadSummary summary) {
        this.summary = summary;
    }

    /** Returns the reload result. */
    public ReloadSummary summary() {
        return summary;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    /** Bukkit handler list accessor. */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}