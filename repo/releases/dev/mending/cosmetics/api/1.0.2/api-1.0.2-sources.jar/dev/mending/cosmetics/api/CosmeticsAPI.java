package dev.mending.cosmetics.api;

import dev.mending.cosmetics.api.item.ItemProvider;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.Optional;
import java.util.UUID;

/**
 * Entry point of the Cosmetics API. Also registered in Bukkit's {@code ServicesManager}.
 * <p>Thread rules: {@link #get()} may be called from any thread.</p>
 */
public interface CosmeticsAPI {

    /**
     * Returns the API instance.
     *
     * @return the API
     * @throws IllegalStateException if the Cosmetics plugin is not enabled
     */
    static CosmeticsAPI get() {
        return CosmeticsAPIProvider.get();
    }

    /** Returns whether the API is currently available. */
    static boolean isAvailable() {
        return CosmeticsAPIProvider.isAvailable();
    }

    /** Returns the cosmetic registry. */
    CosmeticRegistry registry();

    /**
     * Returns the cosmetic user of an online player. A user exists for every online player once the plugin's join
     * handling has completed. In rare cases (data not preloaded, e.g. right after a plugin reload) the user appears
     * one or two ticks after the join event, so treat an empty result as "not ready yet", not as an error.
     * <p>Thread rules: any thread.</p>
     *
     * @param player the player
     * @return the user, if ready
     */
    Optional<CosmeticUser> user(Player player);

    /**
     * Returns the cosmetic user of an online player by uuid.
     * <p>Thread rules: any thread.</p>
     *
     * @param uuid the player's uuid
     * @return the user, if ready
     */
    Optional<CosmeticUser> user(UUID uuid);

    /**
     * Returns a cosmetic's normal item, for example as an icon in a menu. It uses the current definition of the id.
     * The stack is a fresh copy that can be changed freely. It is a real item: it has no marker for the loose-cosmetic
     * guard, so a menu must keep players from taking it out.
     * <p>Thread rules: main thread only.</p>
     *
     * @param cosmetic the cosmetic
     * @return the item, or empty if the cosmetic is not registered or dormant
     */
    Optional<ItemStack> itemStack(Cosmetic cosmetic);

    /**
     * Registers an item provider for a namespace (e.g. {@code itemsadder}). Cosmetics whose item could not be
     * resolved before (dormant) become active automatically if the new provider can create their item.
     * The provider is removed automatically when {@code owner} disables.
     * <p>Thread rules: main thread only.</p>
     *
     * @param owner    the owning plugin
     * @param provider the provider; its namespace must be lowercase {@code [a-z0-9_.-]+} and not yet registered
     * @throws IllegalArgumentException if the namespace is invalid or already taken
     */
    void registerItemProvider(Plugin owner, ItemProvider provider);

    /**
     * Removes an item provider registered by {@code owner}. Built-in providers cannot be removed.
     * <p>Thread rules: main thread only.</p>
     *
     * @param owner     the plugin that registered it
     * @param namespace the provider namespace
     * @return {@code true} if a provider was removed
     */
    boolean unregisterItemProvider(Plugin owner, String namespace);
}