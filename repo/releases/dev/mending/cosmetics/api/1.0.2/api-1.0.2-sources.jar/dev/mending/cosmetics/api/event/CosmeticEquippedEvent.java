package dev.mending.cosmetics.api.event;

import dev.mending.cosmetics.api.Cosmetic;
import dev.mending.cosmetics.api.CosmeticUser;
import dev.mending.cosmetics.api.model.EquipOptions;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.Nullable;

/** Fired on the main thread after a cosmetic has been equipped. Not cancellable. */
public final class CosmeticEquippedEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final CosmeticUser user;
    private final Cosmetic cosmetic;
    private final @Nullable Cosmetic replaced;
    private final EquipOptions options;

    public CosmeticEquippedEvent(CosmeticUser user, Cosmetic cosmetic, @Nullable Cosmetic replaced,
                                 EquipOptions options) {
        this.user = user;
        this.cosmetic = cosmetic;
        this.replaced = replaced;
        this.options = options;
    }

    public CosmeticUser user() {
        return user;
    }

    public Cosmetic cosmetic() {
        return cosmetic;
    }

    /** The cosmetic that was worn in the slot before, or {@code null}. */
    public @Nullable Cosmetic replaced() {
        return replaced;
    }

    public EquipOptions options() {
        return options;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}