package dev.mending.cosmetics.api;

import dev.mending.cosmetics.api.model.EquipCause;
import dev.mending.cosmetics.api.model.EquipOptions;
import dev.mending.cosmetics.api.model.EquipResult;
import net.kyori.adventure.key.Key;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * The cosmetic state of one online player.
 * <p>Thread rules: every method must be called on the main thread unless stated otherwise.</p>
 */
public interface CosmeticUser {

    /** Returns the player. */
    Player player();

    /** Returns the player's uuid (any thread). */
    UUID uuid();

    /**
     * Returns the cosmetic worn in a slot. Dormant cosmetics (item currently unavailable) are included;
     * they are worn but not rendered.
     * <p>Thread rules: any thread (reads an immutable snapshot).</p>
     */
    Optional<Cosmetic> equipped(CosmeticSlot slot);

    /**
     * Returns an unmodifiable snapshot of everything worn.
     * <p>Thread rules: any thread.</p>
     */
    Map<CosmeticSlot, Cosmetic> equipped();

    /** Returns whether the player has the permission to use the cosmetic (free cosmetics: always). */
    boolean canUse(Cosmetic cosmetic);

    /**
     * Equips a cosmetic, replacing whatever is in its slot.
     * Fires {@code CosmeticEquipEvent} (cancellable, a listener may replace the cosmetic), then, on success,
     * {@code CosmeticEquippedEvent}. Replacing fires {@code CosmeticUnequipEvent} with cause REPLACED first.
     * Equipping the cosmetic that is already worn returns {@link EquipResult#ALREADY_EQUIPPED} and changes nothing.
     *
     * @param cosmetic the cosmetic (resolved by id against the current registry)
     * @param options  options
     * @return the result
     */
    EquipResult equip(Cosmetic cosmetic, EquipOptions options);

    /** Same as {@link #equip(Cosmetic, EquipOptions)} with {@link EquipOptions#defaults()}. */
    default EquipResult equip(Cosmetic cosmetic) {
        return equip(cosmetic, EquipOptions.defaults());
    }

    /**
     * Unequips a slot. Fires {@code CosmeticUnequipEvent}; forced causes cannot be cancelled.
     * Unequipping a temporary cosmetic does not touch the stored choice of that slot.
     *
     * @param slot  the slot
     * @param cause the cause
     * @return SUCCESS, NOT_EQUIPPED or CANCELLED
     */
    EquipResult unequip(CosmeticSlot slot, EquipCause cause);

    /** Unequips every slot with cause {@link EquipCause#API}. */
    default void unequipAll() {
        unequipAll(EquipCause.API);
    }

    /** Unequips every slot with the given cause. */
    void unequipAll(EquipCause cause);

    /**
     * Adds a reason to hide all cosmetics: equipment slots show the real items again and the accessory disappears.
     * Fires {@code CosmeticHideEvent} (cancellable). Adding a reason the user already has changes nothing and fires
     * nothing. Nothing is stored, except {@code HideReason.COMMAND}.
     *
     * @param reason the reason, see {@code HideReason} for the namespace to use
     * @return {@code true} if the reason was added
     */
    boolean hide(Key reason);

    /**
     * Removes one reason added by {@link #hide(Key)}. Fires {@code CosmeticShowEvent} (cancellable). The cosmetics come
     * back only when no reason is left.
     *
     * @param reason the reason
     * @return {@code true} if the reason was removed
     */
    boolean show(Key reason);

    /** Returns whether all cosmetics are hidden for at least one reason. Reasons of single slots do not count. */
    boolean isHidden();

    /** Returns whether this reason, added by {@link #hide(Key)}, is active. */
    boolean isHidden(Key reason);

    /** Returns an unmodifiable snapshot of the reasons added by {@link #hide(Key)}. */
    Set<Key> hiddenReasons();

    /**
     * Adds a reason to hide one slot. Fires {@code CosmeticHideEvent} (cancellable) with the slot.
     *
     * @param slot   the slot
     * @param reason the reason
     * @return {@code true} if the reason was added
     */
    boolean hideSlot(CosmeticSlot slot, Key reason);

    /**
     * Removes a reason added by {@link #hideSlot}. Fires {@code CosmeticShowEvent} (cancellable) with the slot.
     *
     * @param slot   the slot
     * @param reason the reason
     * @return {@code true} if the reason was removed
     */
    boolean showSlot(CosmeticSlot slot, Key reason);

    /** Sends the player's cosmetics to all clients again on the next tick, even if nothing changed. */
    void refresh();
}