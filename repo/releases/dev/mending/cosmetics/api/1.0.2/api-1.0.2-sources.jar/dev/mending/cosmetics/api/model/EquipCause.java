package dev.mending.cosmetics.api.model;

/** Why a cosmetic is being equipped or unequipped. */
public enum EquipCause {
    COMMAND,
    API,
    JOIN,
    /** A different cosmetic took the slot. */
    REPLACED,
    /** The player lost the permission. Forced: listeners cannot cancel it. */
    PERMISSION_LOSS,
    /** Removed because of death (settings.unequip-on-death). Forced. */
    DEATH;

    /** Forced causes cannot be cancelled by event listeners. */
    public boolean isForced() {
        return this == PERMISSION_LOSS || this == DEATH;
    }
}