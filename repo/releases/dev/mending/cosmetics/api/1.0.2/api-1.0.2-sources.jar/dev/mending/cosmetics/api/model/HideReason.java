package dev.mending.cosmetics.api.model;

import net.kyori.adventure.key.Key;

/**
 * The built-in reasons why a player's cosmetics are hidden. A reason is a {@link Key}, and a user holds any number of
 * them. Other plugins use their own keys.
 * <p>
 * Use your plugin's name in lower case as the namespace of your keys, e.g. {@code Key.key("myminigame", "round")}:
 * reasons in that namespace are removed automatically when your plugin is disabled.
 * </p>
 */
public final class HideReason {

    /** The namespace of the built-in reasons. */
    public static final String NAMESPACE = "cosmetics";

    /** The player is vanished. Reserved for a vanish hook; nothing in this plugin sets it yet. */
    public static final Key VANISH = Key.key(NAMESPACE, "vanish");
    /** The player has the invisibility potion effect ({@code settings.hide.on-invisibility}). */
    public static final Key INVISIBILITY = Key.key(NAMESPACE, "invisibility");
    /** The player's game mode is listed in {@code settings.hide.gamemodes}. */
    public static final Key GAMEMODE = Key.key(NAMESPACE, "gamemode");
    /** The player's world is listed in {@code settings.hide.disabled-worlds}. */
    public static final Key WORLD = Key.key(NAMESPACE, "world");
    /** The player's own choice through {@code /cosmetics hide}. The only persisted reason. */
    public static final Key COMMAND = Key.key(NAMESPACE, "command");

    private HideReason() {
    }
}
