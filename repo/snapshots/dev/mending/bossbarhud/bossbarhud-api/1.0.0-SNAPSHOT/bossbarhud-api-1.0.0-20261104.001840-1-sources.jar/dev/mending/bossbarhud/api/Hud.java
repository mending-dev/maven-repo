package dev.mending.bossbarhud.api;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

/**
 * A HUD is a named group of boxes that is rendered in the bossbar title.
 * <p>
 * A <b>global</b> HUD is visible to everyone except players it was hidden from.
 * A <b>personal</b> HUD is only visible to players it was shown to.
 * <p>
 * All methods may be called from any thread.
 */
public interface Hud {

    /** The unique key: namespace = lowercase plugin name, value = HUD id. */
    @NotNull Key key();

    @NotNull Plugin owner();

    /** HUDs with a lower priority are rendered further to the left. */
    int priority();

    boolean isGlobal();

    /** Returns false after {@link #unregister()} or when the owning plugin was disabled. */
    boolean isRegistered();

    // ---------------------------------------------------------------- Segments

    /**
     * Adds or replaces a box.
     *
     * @param id       id of the box, unique inside this HUD
     * @param order    boxes are rendered from left to right by ascending order
     * @param provider supplies the content for each viewer
     * @return this HUD for chaining
     */
    @NotNull Hud setSegment(@NotNull String id, int order, @NotNull HudSegmentProvider provider);

    /** Adds or replaces a box with static content. */
    @NotNull Hud setSegment(@NotNull String id, int order, @NotNull Component content);

    /** Removes a box. Returns true if it existed. */
    boolean removeSegment(@NotNull String id);

    /** The ids of all boxes in render order. */
    @NotNull Set<String> segmentIds();

    // ---------------------------------------------------------------- Audience

    /** Shows this HUD to the player (for a global HUD: undoes a previous hide). */
    void show(@NotNull Player player);

    /** Hides this HUD from the player (for a global HUD: excludes the player). */
    void hide(@NotNull Player player);

    boolean isShownTo(@NotNull Player player);

    /** Restores the default audience: everyone for a global HUD, nobody for a personal HUD. */
    void reset();

    // ---------------------------------------------------------------- Rendering

    /** Re-renders this HUD for all current viewers immediately. */
    void refresh();

    /** Re-renders this HUD for one player immediately (if the player can see it). */
    void refresh(@NotNull Player player);

    /** Removes this HUD completely. */
    void unregister();
}