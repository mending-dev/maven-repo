package dev.mending.cosmetics.api.model;

/** Which yaw an accessory follows. */
public enum RotationSource {
    /** Follows the owner's head (camera) yaw. */
    HEAD,
    /** Follows the owner's body yaw. */
    BODY
}