package dev.mending.cosmetics.api;

import org.bukkit.plugin.Plugin;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Read access to all known cosmetics plus registration of cosmetics defined in code.
 * <p>
 * All collections returned are unmodifiable VIEWS of an immutable snapshot (no copying). A view stays
 * consistent but does not reflect later reloads; call the method again to see the new snapshot.
 * Thread rules: read methods are safe from any thread; registration methods must be called on the main thread.
 * </p>
 */
public interface CosmeticRegistry {

    /**
     * Finds a cosmetic by id.
     *
     * @param id exact lowercase id
     * @return the cosmetic, or empty
     */
    Optional<Cosmetic> find(String id);

    /**
     * Returns whether the id is known.
     *
     * @param id exact lowercase id
     * @return {@code true} if present
     */
    boolean contains(String id);

    /** Returns all cosmetics sorted by id (unmodifiable view, no copy). */
    Collection<Cosmetic> all();

    /** Returns the number of cosmetics. */
    int size();

    /**
     * Returns all cosmetics of a slot sorted by id (precomputed view).
     *
     * @param slot the slot
     * @return unmodifiable list, never {@code null}
     */
    List<Cosmetic> bySlot(CosmeticSlot slot);

    /**
     * Returns all cosmetics of a category sorted by id (precomputed view).
     *
     * @param category the category, case-insensitive
     * @return unmodifiable list, never {@code null}
     */
    List<Cosmetic> byCategory(String category);

    /** Returns all known categories (unmodifiable view). */
    Set<String> categories();

    /** Streams all cosmetics sorted by id. */
    Stream<Cosmetic> stream();

    /**
     * Registers a cosmetic defined in code. It survives reloads and is removed when {@code owner} disables.
     * File-defined cosmetics win over code-defined ones with the same id.
     *
     * @param owner     the owning plugin
     * @param cosmetic  the cosmetic
     * @throws IllegalArgumentException if the id is already registered
     */
    void register(Plugin owner, Cosmetic cosmetic);

    /**
     * Registers several cosmetics at once (one index rebuild). Either all or none are registered.
     *
     * @param owner      the owning plugin
     * @param cosmetics  the cosmetics
     * @throws IllegalArgumentException if any id is already registered
     */
    void registerAll(Plugin owner, Collection<Cosmetic> cosmetics);

    /**
     * Removes a code-defined cosmetic.
     *
     * @param owner the plugin that registered it
     * @param id    the cosmetic id
     * @return {@code true} if something was removed
     */
    boolean unregister(Plugin owner, String id);
}