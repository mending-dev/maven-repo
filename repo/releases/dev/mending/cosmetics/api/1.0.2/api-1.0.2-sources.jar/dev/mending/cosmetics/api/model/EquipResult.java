package dev.mending.cosmetics.api.model;

/** Result of an equip or unequip call. */
public enum EquipResult {
    SUCCESS,
    /** The same cosmetic is already worn in that slot (nothing changed). */
    ALREADY_EQUIPPED,
    /** Unequip: nothing was worn in that slot. */
    NOT_EQUIPPED,
    NO_PERMISSION,
    /** An event listener cancelled the change. */
    CANCELLED,
    /** The cosmetic's item cannot be resolved right now (see dormant cosmetics). */
    DORMANT,
    /** The cosmetic is not (or no longer) in the registry. */
    UNKNOWN_COSMETIC;

    public boolean isSuccess() {
        return this == SUCCESS;
    }
}