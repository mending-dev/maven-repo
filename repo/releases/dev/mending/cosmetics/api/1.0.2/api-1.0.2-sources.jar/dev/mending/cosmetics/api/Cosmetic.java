package dev.mending.cosmetics.api;

import dev.mending.cosmetics.api.item.ItemSpec;
import dev.mending.cosmetics.api.model.AccessoryOptions;
import org.bukkit.permissions.Permissible;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;

/**
 * An immutable cosmetic definition.
 *
 * @param id              globally unique id, {@code [a-z0-9_]+}
 * @param slot            the slot it occupies
 * @param name            MiniMessage display name for lists and menus
 * @param item            the item shown to everybody
 * @param firstPersonItem ACCESSORY only: item shown to the owner in first person (may be {@code null})
 * @param permission      required permission, {@code null} = free for everyone
 * @param category        lowercase category
 * @param description     MiniMessage description lines
 * @param accessory       accessory options ({@link AccessoryOptions#EMPTY} for non-accessory slots)
 * @param origin          free text describing where it came from (file path or plugin name)
 */
public record Cosmetic(
        String id,
        CosmeticSlot slot,
        String name,
        ItemSpec item,
        @Nullable ItemSpec firstPersonItem,
        @Nullable String permission,
        String category,
        List<String> description,
        AccessoryOptions accessory,
        String origin
) {
    /** Allows using every cosmetic, whatever its own permission is. */
    public static final String ALL_PERMISSION = "cosmetics.all";

    /** Maximum id length. */
    public static final int MAX_ID_LENGTH = 64;

    public Cosmetic {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(slot, "slot");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(item, "item");
        Objects.requireNonNull(category, "category");
        Objects.requireNonNull(accessory, "accessory");
        Objects.requireNonNull(origin, "origin");
        if (!isValidId(id)) {
            throw new IllegalArgumentException("invalid cosmetic id '" + id + "' (allowed: [a-z0-9_]+, max "
                    + MAX_ID_LENGTH + " chars)");
        }
        if (firstPersonItem != null && slot != CosmeticSlot.ACCESSORY) {
            throw new IllegalArgumentException("firstPersonItem is only allowed for ACCESSORY cosmetics");
        }
        if (permission != null && permission.isBlank()) {
            permission = null;
        }
        description = List.copyOf(description);
    }

    /**
     * Checks the id format {@code [a-z0-9_]+}.
     *
     * @param id candidate id
     * @return {@code true} if valid
     */
    public static boolean isValidId(@Nullable String id) {
        if (id == null || id.isEmpty() || id.length() > MAX_ID_LENGTH) {
            return false;
        }
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_')) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns whether a player may use this cosmetic: it is free, or they have its permission or
     * {@link #ALL_PERMISSION}. Main thread only.
     *
     * @param player the player
     * @return {@code true} if allowed
     */
    public boolean isUsableBy(Permissible player) {
        return isFree() || player.hasPermission(permission) || player.hasPermission(ALL_PERMISSION);
    }

    /** Returns {@code true} if anybody may use this cosmetic without a permission. */
    public boolean isFree() {
        return permission == null;
    }

    /** Returns {@code true} if a first-person item is defined. */
    public boolean hasFirstPersonItem() {
        return firstPersonItem != null;
    }
}