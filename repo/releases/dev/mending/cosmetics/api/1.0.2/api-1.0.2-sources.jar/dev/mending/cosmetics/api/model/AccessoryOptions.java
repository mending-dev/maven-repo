package dev.mending.cosmetics.api.model;

import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

/**
 * Per-cosmetic accessory settings. A {@code null} component means "use the global default from config.yml".
 *
 * @param rotationSource     yaw source override
 * @param firstPersonHeight  number of area effect clouds in the first-person chain
 * @param hideWhen           states in which the accessory is hidden (empty set = never hide by state)
 */
public record AccessoryOptions(
        @Nullable RotationSource rotationSource,
        @Nullable Integer firstPersonHeight,
        @Nullable Set<AccessoryState> hideWhen
) {
    /** No overrides at all. */
    public static final AccessoryOptions EMPTY = new AccessoryOptions(null, null, null);

    public AccessoryOptions {
        if (hideWhen != null) {
            hideWhen = hideWhen.isEmpty()
                    ? Set.of()
                    : Collections.unmodifiableSet(EnumSet.copyOf(hideWhen));
        }
    }

    /**
     * Fills every {@code null} component with the value of {@code fallback}.
     *
     * @param fallback the options to inherit from
     * @return merged options
     */
    public AccessoryOptions withDefaults(AccessoryOptions fallback) {
        return new AccessoryOptions(
                rotationSource != null ? rotationSource : fallback.rotationSource,
                firstPersonHeight != null ? firstPersonHeight : fallback.firstPersonHeight,
                hideWhen != null ? hideWhen : fallback.hideWhen
        );
    }
}