package dev.mending.bossbarhud.api;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

/**
 * A HUD is a named group of boxes that is rendered in the bossbar title.
 * <p>
 * A <b>global</b> HUD is visible to everyone except players it was hidden from.
 * A <b>personal</b> HUD is only visible to players it was shown to.
 * <p>
 * Boxes are placed on lines. Boxes on the same line are placed next to each other,
 * every line is rendered below the previous one.
 * <p>
 * All methods may be called from any thread.
 */
public interface Hud {

    /** The line that is used when no line is given. */
    int DEFAULT_LINE = 1;

    /** The unique key: namespace = lowercase plugin name, value = HUD id. */
    @NotNull Key key();

    @NotNull Plugin owner();

    /** HUDs with a lower priority are rendered further to the left inside a line. */
    int priority();

    boolean isGlobal();

    /** Returns false after {@link #unregister()} or when the owning plugin was disabled. */
    boolean isRegistered();

    // ---------------------------------------------------------------- Segments

    /**
     * Adds or replaces a box on {@link #DEFAULT_LINE}.
     *
     * @param id       id of the box, unique inside this HUD
     * @param order    position inside the line, boxes are rendered from left to right by ascending order
     * @param provider supplies the content for each viewer
     * @return this HUD for chaining
     */
    @NotNull Hud setSegment(@NotNull String id, int order, @NotNull HudSegmentProvider provider);

    /**
     * Adds or replaces a box.
     * <p>
     * Lines are shared between all HUDs. Only the relative order of the lines counts: if the lines 1 and 5
     * are used there are two rows, and a single box is always in the first row.
     *
     * @param id       id of the box, unique inside this HUD
     * @param line     the line (row) of the box, boxes with the same line are placed next to each other
     * @param order    position inside the line, boxes are rendered from left to right by ascending order
     * @param provider supplies the content for each viewer
     * @return this HUD for chaining
     */
    @NotNull Hud setSegment(@NotNull String id, int line, int order, @NotNull HudSegmentProvider provider);

    /** Adds or replaces a box with static content on {@link #DEFAULT_LINE}. */
    @NotNull Hud setSegment(@NotNull String id, int order, @NotNull Component content);

    /** Adds or replaces a box with static content. See {@link #setSegment(String, int, int, HudSegmentProvider)}. */
    @NotNull Hud setSegment(@NotNull String id, int line, int order, @NotNull Component content);

    /** Removes a box. Returns true if it existed. */
    boolean removeSegment(@NotNull String id);

    /** The ids of all boxes of this HUD, sorted by line and order. */
    @NotNull Set<String> segmentIds();

    // ---------------------------------------------------------------- Audience

    /** Shows this HUD to the player (for a global HUD: undoes a previous hide). */
    void show(@NotNull Player player);

    /** Hides this HUD from the player (for a global HUD: excludes the player). */
    void hide(@NotNull Player player);

    boolean isShownTo(@NotNull Player player);

    /** Restores the default audience: everyone for a global HUD, nobody for a personal HUD. */
    void reset();

    // ---------------------------------------------------------------- Rendering

    /** Re-renders this HUD for all current viewers immediately. */
    void refresh();

    /** Re-renders this HUD for one player immediately (if the player can see it). */
    void refresh(@NotNull Player player);

    /** Removes this HUD completely. */
    void unregister();
}