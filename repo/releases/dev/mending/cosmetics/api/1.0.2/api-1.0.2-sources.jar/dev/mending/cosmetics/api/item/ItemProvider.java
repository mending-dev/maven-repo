package dev.mending.cosmetics.api.item;

import org.bukkit.inventory.ItemStack;

import java.util.Optional;

/**
 * SPI for item sources. Built-in namespaces: {@code minecraft} and {@code nexo}.
 * Other plugins register providers through {@code CosmeticsAPI#registerItemProvider}.
 * <p>Thread rules: all methods are called on the main thread.</p>
 */
public interface ItemProvider {

    /** Returns the lowercase namespace this provider handles. */
    String namespace();

    /**
     * Creates a fresh item stack.
     *
     * @param id the id without namespace
     * @return the item, or empty if it does not exist (yet)
     */
    Optional<ItemStack> create(String id);

    /**
     * Cheap existence check.
     *
     * @param id the id without namespace
     * @return {@code true} if {@link #create(String)} would succeed
     */
    boolean exists(String id);
}