package dev.mending.cosmetics.api.model;

import java.util.Objects;

/**
 * Options for {@code CosmeticUser#equip}.
 *
 * @param persist          {@code false} = temporary: not saved, and the stored choice of that slot is kept
 * @param bypassPermission skip the permission check; such cosmetics are also exempt from permission revalidation
 * @param silent           suppress feedback messages (events still fire)
 * @param cause            the cause reported to events
 */
public record EquipOptions(boolean persist, boolean bypassPermission, boolean silent, EquipCause cause) {

    /** persist = true, no bypass, not silent, cause API. */
    public static final EquipOptions DEFAULT = new EquipOptions(true, false, false, EquipCause.API);

    public EquipOptions {
        Objects.requireNonNull(cause, "cause");
    }

    public static EquipOptions defaults() {
        return DEFAULT;
    }

    public EquipOptions withPersist(boolean persist) {
        return new EquipOptions(persist, bypassPermission, silent, cause);
    }

    public EquipOptions withBypassPermission(boolean bypassPermission) {
        return new EquipOptions(persist, bypassPermission, silent, cause);
    }

    public EquipOptions withSilent(boolean silent) {
        return new EquipOptions(persist, bypassPermission, silent, cause);
    }

    public EquipOptions withCause(EquipCause cause) {
        return new EquipOptions(persist, bypassPermission, silent, cause);
    }
}