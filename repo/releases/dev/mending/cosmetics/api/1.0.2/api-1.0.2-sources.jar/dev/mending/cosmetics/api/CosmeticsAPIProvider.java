package dev.mending.cosmetics.api;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Internal holder for the single API instance. Not for use by other plugins.
 */
@ApiStatus.Internal
public final class CosmeticsAPIProvider {

    private static volatile @Nullable CosmeticsAPI instance;

    private CosmeticsAPIProvider() {
    }

    static CosmeticsAPI get() {
        CosmeticsAPI api = instance;
        if (api == null) {
            throw new IllegalStateException("The Cosmetics plugin is not enabled");
        }
        return api;
    }

    static boolean isAvailable() {
        return instance != null;
    }

    /** Internal: called by the plugin on enable. */
    @ApiStatus.Internal
    public static void register(CosmeticsAPI api) {
        instance = api;
    }

    /** Internal: called by the plugin on disable. */
    @ApiStatus.Internal
    public static void unregister() {
        instance = null;
    }
}