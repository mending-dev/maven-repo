package dev.mending.bossbarhud.api;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.Optional;

/**
 * Public API of BossbarHud. Obtain it via {@link #get()}.
 *
 * <pre>{@code
 * Hud hud = HudAPI.get().createHud(plugin, "minigame")
 *         .segment("score", 0, p -> Component.text("Score: " + score(p)))
 *         .build();
 * hud.show(player);   // send to one player
 * hud.hide(player);   // remove from one player
 * hud.unregister();   // remove completely
 * }</pre>
 */
public interface HudAPI {

    /**
     * Returns the registered API instance.
     *
     * @throws IllegalStateException if BossbarHud is not enabled
     */
    static @NotNull HudAPI get() {
        RegisteredServiceProvider<HudAPI> registration = Bukkit.getServicesManager().getRegistration(HudAPI.class);
        if (registration == null) {
            throw new IllegalStateException("BossbarHud is not enabled");
        }
        return registration.getProvider();
    }

    // ---------------------------------------------------------------- Create

    /**
     * Starts building a HUD. The id must be unique per plugin and may only contain
     * lowercase letters, digits and the characters _ - . /
     */
    @NotNull HudBuilder createHud(@NotNull Plugin owner, @NotNull String id);

    /**
     * Shortcut: sends static boxes to one player. The returned HUD is removed
     * automatically when the player leaves; call {@link Hud#unregister()} to remove it earlier.
     */
    @NotNull Hud send(@NotNull Plugin owner, @NotNull Player player, @NotNull Component... boxes);

    // ---------------------------------------------------------------- Query

    @NotNull Optional<Hud> getHud(@NotNull Plugin owner, @NotNull String id);

    /** All registered HUDs, sorted by priority. */
    @NotNull Collection<Hud> getHuds();

    @NotNull Collection<Hud> getHuds(@NotNull Plugin owner);

    /** The HUDs the player currently sees, sorted by priority. */
    @NotNull Collection<Hud> getHuds(@NotNull Player player);

    // ---------------------------------------------------------------- Remove

    /** Unregisters all HUDs of a plugin. This also happens automatically when the plugin is disabled. */
    void unregisterAll(@NotNull Plugin owner);

    /** Unregisters every HUD of every plugin, including the HUD from config.yml (restored by /bossbarhud reload). */
    void unregisterAll();

    /** Hides every HUD (global and personal) from this player. Undo with {@link #reset(Player)}. */
    void clear(@NotNull Player player);

    /** Removes all per-player overrides, so the player sees the default audience of every HUD again. */
    void reset(@NotNull Player player);

    // ---------------------------------------------------------------- Per player switches

    /** Master switch: hides or shows the whole HUD for a player without touching HUD assignments. */
    void setHidden(@NotNull Player player, boolean hidden);

    boolean isHidden(@NotNull Player player);

    // ---------------------------------------------------------------- Rendering

    void refresh(@NotNull Player player);

    void refreshAll();

    /** Wraps any content into a box background with the correct length. */
    @NotNull Component box(@NotNull Component content);

    /** Returns the pixel width of a component (including the trailing 1px spacing). */
    int measure(@NotNull Component content);

    /** Registers the pixel width (including the 1px spacing) of a custom glyph character. */
    void registerGlyphWidth(char glyph, int width);
}